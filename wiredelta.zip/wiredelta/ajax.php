<?PHP include("config.php");
$_REQUEST['data_value']=str_replace( ' aria-required="true"', '', $_REQUEST['data_value']);
$sql = mysql_query("INSERT INTO html_data (template_data) VALUES ('".mysql_real_escape_string($_REQUEST['data_value'])."')");
?>