<?php error_reporting(0);
// we connect to localhost at port 3307
$link = mysql_connect('localhost', 'root', '');
if (!$link) {
    //die('Could not connect: ' . mysql_error());
}
//mysql_close($link);
mysql_select_db('wiredelta', $link);
?>